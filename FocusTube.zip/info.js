document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('back').addEventListener('click', () => {
    window.location.href = 'options.html';
  });
}); 